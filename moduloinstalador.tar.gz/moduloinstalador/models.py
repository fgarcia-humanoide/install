# -*- coding: utf-8 -*-

from openerp import models, fields, api

# class moduloinstalador(models.Model):
#     _name = 'moduloinstalador.moduloinstalador'

#     name = fields.Char()