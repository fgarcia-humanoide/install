v1.0.0
======
By installing this module you will be able to:
 * see the DB name beside current accessed user name without needing to debug mode.
